int dlclose(void *handle) { return 0; }
