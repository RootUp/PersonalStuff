#include "waypoints.h"
FUZZFACTORY_DSF_NEW(__afl_mem_dsf, 1 << 10, FUZZFACTORY_REDUCER_MAX, 0);
