#include "waypoints.h"
FUZZFACTORY_DSF_NEW(__afl_slow_dsf, 1, FUZZFACTORY_REDUCER_MAX, 0);
